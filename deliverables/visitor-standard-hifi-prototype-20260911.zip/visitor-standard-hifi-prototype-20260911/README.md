# 访客系统一期标品高保真原型

双击 `index.html` 进入原型。

正式页面：

- `super-admin.html`：超级管理端
- `tenant-admin.html`：租户管理端
- `frontends/enterprise-h5.html`：企业统一前台
- `frontends/guard-terminal.html`：扫码设备端，主分辨率 1280×800

本包为纯前端可交互高保真原型，不需要安装 Java、MySQL、Redis 或后端服务。请保持目录结构完整，避免页面资源丢失。

本包不包含客户定制版本、历史访客/被访人独立入口、后端 JAR、数据库、测试报告和内部研发文档。
